<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$data = array(
			'title' => 'GIS',
			'isi' => 'home' 
		);
		$this->load->view('template/wrapper', $data, FALSE);
	}

	public function covid19()
	{
		$data = array(
			'title' => 'Persebaran Covid di Kab. Lombok Tengah',
			'isi' => 'covid19' 
		);
		$this->load->view('template/wrapper', $data, FALSE);
	}

	public function mapstki()
	{
		$data = array(
			'title' => 'Persebaran TKI/TKW di Kab. Lombok Tengah',
			'isi' => 'mapstki' 
		);
		$this->load->view('template/wrapper', $data, FALSE);
	}

}
