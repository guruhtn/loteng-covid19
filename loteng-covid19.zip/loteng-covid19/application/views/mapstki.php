
<div id="map" style="width: auto; height:610px;"></div>

<script type="text/javascript">
	/*Membuat BaseMap Pada Peta*/
	var mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

	var streets  = L.tileLayer(mbUrl, {id: 'mapbox.streets',   attribution: mbAttr});
	
	/*Mendeklarasikan Peta kedalam Id Map*/
	var map = L.map('map', {
		center: [-8.6416479, 116.3522657],
		zoom: 11,
		layers: [streets]
	});

	
	/*Membuat Icon Pada Peta */
	var mapIcon = L.Icon.extend({
	    iconSize:     [32, 37]
	});
	/*Kecamatan Icon*/
	var prayaIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/1-praya.png') ?>'});
	    jonggatIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/2-jonggat.png') ?>'});
	    batukeliangIcon2 = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/3-btklu.png') ?>'});
	    batukeliangIcon1 = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/4-btkl.png') ?>'});
	    prabaIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/5-praba.png') ?>'});
	    janapriaIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/6-jpr.png') ?>'});
	    kopangIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/7-kopang.png') ?>'});
	    prabadaIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/8-prabada.png') ?>'});
	    pratengIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/9-prateng.png') ?>'});
	    pratimIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/10-pratim.png') ?>'});
	    pujutIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/pjt.png') ?>'});
	    pringarataIcon = new mapIcon({iconUrl: ' <?php echo base_url('assets/icon/12-pringgarata.png') ?>'});
	    /*Kecamatan Icon*/

	/*Mendeklarasikan Marker kecamayan dan membuatnya menjadi Layer Group*/
	var kc1 = L.marker([-8.6128813, 116.3103312],{icon: batukeliangIcon1}).bindPopup("<b>Kantor Camat Batukeliang</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Batukliag.jpg')?>' alt='kecamatan ' width='300px'/>");
	var kc2 = L.marker([-8.588949, 116.3245473],{icon: batukeliangIcon2}).bindPopup("<b>Kantor Camat Batukeliang Utara</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Batukliang Utara.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc3 = L.marker([-8.6942821, 116.3995881],{icon: janapriaIcon}).bindPopup("<b>Kantor Camat Janapria</b><br> <img src='<?php echo base_url('assets/img/kantor camat janapria.jpg') ?>' alt='kecamatan ' width='300px'/>");
    var kc4 = L.marker([-8.6525193, 116.1979991],{icon: jonggatIcon}).bindPopup("<b>Kantor Camat Jonggat</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Jonggat.jpg') ?>' alt='kecamatan ' width='300px'/>");
    var kc5 = L.marker([-8.6343426, 116.3548378],{icon: kopangIcon}).bindPopup("<b>Kantor Camat Kopang</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Kopang.jpg') ?>' alt='kecamatan ' width='300px'/>");
    var kc6 = L.marker([-8.7069416,116.266245],{icon: prayaIcon}).bindPopup("<b>Kantor Camat Praya</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Praya.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc7 = L.marker([-8.742301, 116.2410837],{icon: prabaIcon}).bindPopup("<b>Kantor Camat Praya Barat</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Praya Barat.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc8 = L.marker([-8.7385415, 116.2015728],{icon: prabadaIcon}).bindPopup("<b>Kantor Camat Praya Barat Daya</b><br> <img src='<?php echo base_url('assets/img/kantor camat praya barat daya.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc9 = L.marker([-8.7340447, 116.316331],{icon: pratengIcon}).bindPopup("<b>Kantor Camat Praya Tengah</b><br> <img src='<?php echo base_url('assets/img/kantor Camat praya.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc10 = L.marker([-8.7614541, 116.3561055],{icon: pratimIcon}).bindPopup("<b>Kantor Camat Praya Timur</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Praya Timur.jpg') ?>' alt='kecamatan ' width='300px' color='red'/>");
	var kc11 = L.marker([-8.6190863,116.2519556],{icon: pringarataIcon}).bindPopup("<b>Kantor Camat Pringarata</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Pringgarata.jpg') ?>' alt='kecamatan ' width='300px'/>");
	var kc12 = L.marker([-8.8004563, 116.292598],{icon: pujutIcon}).bindPopup("<b>Kantor Camat Pujut</b><br> <img src='<?php echo base_url('assets/img/kantor Camat Pujut.jpg') ?>' alt='kecamatan ' width='300px'/>");

	var kecamatan = L.layerGroup([kc1, kc2, kc3, kc4, kc5, kc6, kc7, kc8, kc9, kc10, kc11, kc12]);
	
	/*Mendeklarasikan BaseLayer Pada Map yakni Street*/
	var baseLayers = {
		"Streets": streets
	};

	
	var batukliangutara = L.geoJSON([btklu], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var batukliang = L.geoJSON([btkl], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var kopang = L.geoJSON([kpg], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var janapria = L.geoJSON([jnp], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var jonggat = L.geoJSON([jgt], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});

	var pringarata = L.geoJSON([pggt], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var praya = L.geoJSON([praya], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var prabarda = L.geoJSON([prabarda], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var prabar = L.geoJSON([prabar], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});

	var prateng = L.geoJSON([prateng], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var pratim = L.geoJSON([pratim], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});
	var pujut = L.geoJSON([pjt], {
		style:function(feature){
			return feature.properties && feature.properties.style;
		}
	});

	/*Deklarasi untuk memilih Icon yang akan ditampilkan*/
	var overlays = {
		"kecamatan" : kecamatan,
		"Kec. Batuklaiang Utara": batukliangutara,
		"Kec. Batuklaiang": batukliang,
		"Kec. Kopang": kopang,
		"Kec. Janapria": janapria,
		"Kec. Pringarata": pringarata,
		"Kec. Jonggat": jonggat,
		"Kec. Praya": praya,
		"Kec. Praya Barat Daya": prabarda,
		"Kec. Praya Barat": prabar,
		"Kec. Praya Tengah": prateng,
		"Kec. Praya Timur": pratim,
		"Kec. Pujut": pujut,
	};

	/*Menambah  variabel baselayaer dan overlay kedalam map*/
	L.control.layers(baseLayers, overlays).addTo(map);

	/*Menbambil data geospesial wilayak kecamatan praya*/
	L.geoJSON([btskab], {
		style: function (feature) {
			return feature.properties && feature.properties.style;
		}
	}).addTo(map);
</script>