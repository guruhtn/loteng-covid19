
<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
  <div id="wrapper">
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
	    <div class="top-area">
	        <div class="container">
	          <div class="row">
	            <div class="col-sm-6 col-md-6">
	              <p class="bold text-left"><b>Posko Tanggap Darurat</b> - <?php echo $title;?> </p>
	            </div>
	            <div class="col-sm-6 col-md-6">
	              <p class="bold text-right">Hubungi Sekang : +62 008 65 001</p>
	            </div>
	          </div>
	        </div>
	    </div>