		<div class="container navigation">
	        <div class="navbar-header page-scroll">
	          	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse"><i class="fa fa-bars"></i>
	            </button>
	          		<a class="navbar-brand" href="#">
	                    <img src="<?php echo base_url();?>assets/loteng/img/logo1.png" alt="" width="150" height="40" />
	                </a>
	        </div>
	        <!-- Collect the nav links, forms, and other content for toggling -->
	        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
	          	<ul class="nav navbar-nav">
		            <li class="active"><a href="<?php echo base_url('Home')?>">Home</a></li>
		            <li><a href="<?php echo base_url('Home/covid19')?>">Persebaran Covid19</a></li>
		            <li><a href="<?php echo base_url('Home/mapstki')?>">Persebaran TKI/TKW</a></li>
	          	</ul>
	        </div>
        <!-- /.navbar-collapse -->
      	</div>
      <!-- /.container -->
    </nav>
<section id="facilities" class="home-section paddingbot-60">