<!DOCTYPE html>
<html lang="en">

<head>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<meta name="description" content="">
  	<meta name="author" content="">

  	<title>Loteng | <?php echo $title ?></title>

  	<!-- css -->
  	<link href="<?php echo base_url();?>assets/loteng/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  	<link href="<?php echo base_url();?>assets/loteng/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  	<link rel="<?php echo base_url();?>assets/loteng/stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
  	<link href="<?php echo base_url();?>assets/loteng/css/nivo-lightbox.css" rel="stylesheet" />
  	<link href="<?php echo base_url();?>assets/loteng/css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
  	<link href="<?php echo base_url();?>assets/loteng/css/owl.carousel.css" rel="stylesheet" media="screen" />
  	<link href="<?php echo base_url();?>assets/loteng/css/owl.theme.css" rel="stylesheet" media="screen" />
  	<link href="<?php echo base_url();?>assets/loteng/css/animate.css" rel="stylesheet" />
  	<link href="<?php echo base_url();?>assets/loteng/css/style.css" rel="stylesheet">

  	<!-- boxed bg -->
  	<link id="bodybg" href="<?php echo base_url();?>assets/loteng/bodybg/bg1.css" rel="stylesheet" type="text/css" />
  	<!-- template skin -->
    <link id="t-colors" href="<?php echo base_url();?>assets/loteng/color/default.css" rel="stylesheet">

	<link href="<?php echo base_url('assets/leaflet/leaflet.css');?>" rel="stylesheet">
	<script src="<?php echo base_url('assets/leaflet/leaflet.js');?>"></script>
	<script src="<?php echo base_url('assets/json/lotengkab.js');?>"></script>
	<style>
		#map {
			width: 100%;
			height:100%;
		}
		.leaflet-popup-content {
			width:auto !important;
		}
      .info { 
        padding: 6px 8px; 
        font: 16px/18px Arial, Helvetica, sans-serif; 
        background: white; 
        background: rgba(255,255,255,0.8); 
        box-shadow: 0 0 15px rgba(0,0,0,0.2); 
        border-radius: 5px; 
        background-color: #21eeec;
      } 
      .info h4 { 
        margin: 0 0 5px; 
        color: #fff; 
      }
      .legend { 
        text-align: right; 
        line-height: 18px; 
        color: #21eeec; 
      } 
      .legend i { 
        width: 18px; 
        height: 18px; 
        float: left; 
        margin-right: 8px; 
        opacity: 0.7; 
      }
    </style>
</head>