
<div id="map" style="width: auto; height:510px;"></div>

<script type="text/javascript">
	var map = L.map('map').setView([-8.7217185,116.2798422], 12);

	L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	id: 'mapbox/streets-v11',
	tileSize: 512,
	zoomOffset: -1
	}).addTo(map);

	var icon1 = L.icon({
	    iconUrl: '<?php echo base_url('assets/icons/14.png');?>',
	    iconSize:     [38, 50], // size of the icon
	    iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
	    popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
	});

	var icon2 = L.icon({
	    iconUrl: '<?php echo base_url('assets/icons/15.png');?>',
	    iconSize:     [38, 50], // size of the icon
	    iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
	    popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
	});

	var icon3 = L.icon({
	    iconUrl: '<?php echo base_url('assets/icons/16.png');?>',
	    iconSize:     [38, 50], // size of the icon
	    iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
	    popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
	});

	var marker = L.marker([-8.7069416,116.266245],{icon:icon1}).bindPopup("<b>Hello world!</b><br>Praya").addTo(map); /*Camat Praya*/

	var marker = L.marker([-8.801371,116.2920534],{icon:icon1}).bindPopup("<b>Pujut</b><br>5 ODP<br>4 PDP").addTo(map); /*Camat Pujut*/

	var marker = L.marker([-8.7281269,116.301241],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Prateng").addTo(map); /*Camat Prateng*/

	var marker = L.marker([-8.7584972,116.33626],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Pratim").addTo(map); /*Camat Pratim*/

	var marker = L.marker([-8.6342573,116.3549078],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Kopang").addTo(map); /*Camat Kopang*/

	var marker = L.marker([-8.652450, 116.200207],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Jonggat").addTo(map); /*Camat Jonggat*/

	var marker = L.marker([-8.6943781,116.40183],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Janeprie").addTo(map); /*Camat Janeprie*/

	var marker = L.marker([-8.7423712,116.2411154],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Praya Barat").addTo(map); /*Camat Praya Barat*/

	var marker = L.marker([-8.7383966,116.2010723],{icon:icon3}).bindPopup("<b>Hello world!</b><br>Praya Barat Daya").addTo(map); /*Camat Praya Barat Daya*/

	var marker = L.marker([-8.6190863,116.2519556],{icon:icon2}).bindPopup("<b>Hello world!</b><br>Pringgarata").addTo(map); /*Camat Pringgarata*/

	var marker = L.marker([-8.6125431,116.3099678],{icon:icon3}).bindPopup("<b>Hello world!</b><br>Batukliang").addTo(map); /*Camat Batukliang*/

	var marker = L.marker([-8.5890638,116.326681],{icon:icon3}).bindPopup("<b>Hello world!</b><br>Batukliang Utara").addTo(map); /*Camat Batukliang Utara*/

</script>