# loteng-covid19
Persebaran Covid19 di Lombok Tengah
